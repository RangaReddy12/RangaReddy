package march10;
import java.sql.*;
public class DbConnect
{
public static void main(String args[])throws Exception
{
 	//loding jdbc
Class.forName("com.mysql.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/citibank","root","");
   Statement stmt=con.createStatement();
  //To Insert Records
//stmt.executeUpdate("insert into emp values('selenium',205,20000)");
  //To update records
//stmt.executeUpdate ("UPDATE emp SET eno=210 WHERE eno=205");
   //update cname
//stmt.executeUpdate("UPDATE emp SET ename='john' WHERE ename='selenium'");
   //To dalete record
  //stmt.execute("Delete FROM emp  WHERE ename='john'");
  stmt.execute("DROP DATABASE citibank");
}
}

